-------------------------------------------------------------------------------
Copyright � 2004 Sun Microsystems, Inc. All rights reserved. Use is
subject to license terms.

This program is free software; you can redistribute it and/or modify
it under the terms of the Lesser GNU General Public License as
published by the Free Software Foundation; either version 2 of the
License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
USA
-------------------------------------------------------------------------------

SaverBeans Screensaver Pack Windows README
------------------------------------------

Requirements:
  * Administrator access, to copy screensaver to Windows system directory
  * Windows ME or XP (may work on other versions of Windows as well)
  * Java VM 1.4 or higher (Get at http://java.com/)

To Install:
  * Copy all files in this directory (except for this README) to
    your Windows system directory (e.g. c:\windows\system32).

To Run:
  * Go to screensaver settings - the new screensavers will appear there.
    For a basic example, look for BouncingLine.
